package com.example.riddhi.ttcapplicationtest1;

public final class Webhook {
    public static final String IPADDRESS = "http://172.26.228.49:56905";
}
